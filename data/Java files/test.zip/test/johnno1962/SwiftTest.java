
package org.genie;

public class SwiftTest {

    public SwiftTest() {
    }

    public static boolean booleanFieldStatic;
    public boolean booleanField;

    public static boolean booleanMethodStatic( boolean arg ) {
        return arg;
    }

    public boolean booleanMethod( boolean arg ) {
        return arg;
    }

    public static boolean booleanArrayFieldStatic[];
    public boolean booleanArrayField[];

    public static boolean[] booleanArrayMethodStatic( boolean arg[] ) {
        return arg;
    }

    public boolean[] booleanArrayMethod( boolean arg[] ) {
        return arg;
    }

    public static boolean boolean2dArrayFieldStatic[][];
    public boolean boolean2dArrayField[][];

    public static boolean[][] boolean2dArrayMethodStatic( boolean arg[][] ) {
        return arg;
    }

    public boolean[][] boolean2dArrayMethod( boolean arg[][] ) {
        return arg;
    }

    public static byte byteFieldStatic;
    public byte byteField;

    public static byte byteMethodStatic( byte arg ) {
        return arg;
    }

    public byte byteMethod( byte arg ) {
        return arg;
    }

    public static byte byteArrayFieldStatic[];
    public byte byteArrayField[];

    public static byte[] byteArrayMethodStatic( byte arg[] ) {
        return arg;
    }

    public byte[] byteArrayMethod( byte arg[] ) {
        return arg;
    }

    public static byte byte2dArrayFieldStatic[][];
    public byte byte2dArrayField[][];

    public static byte[][] byte2dArrayMethodStatic( byte arg[][] ) {
        return arg;
    }

    public byte[][] byte2dArrayMethod( byte arg[][] ) {
        return arg;
    }

    public static char charFieldStatic;
    public char charField;

    public static char charMethodStatic( char arg ) {
        return arg;
    }

    public char charMethod( char arg ) {
        return arg;
    }

    public static char charArrayFieldStatic[];
    public char charArrayField[];

    public static char[] charArrayMethodStatic( char arg[] ) {
        return arg;
    }

    public char[] charArrayMethod( char arg[] ) {
        return arg;
    }

    public static char char2dArrayFieldStatic[][];
    public char char2dArrayField[][];

    public static char[][] char2dArrayMethodStatic( char arg[][] ) {
        return arg;
    }

    public char[][] char2dArrayMethod( char arg[][] ) {
        return arg;
    }

    public static short shortFieldStatic;
    public short shortField;

    public static short shortMethodStatic( short arg ) {
        return arg;
    }

    public short shortMethod( short arg ) {
        return arg;
    }

    public static short shortArrayFieldStatic[];
    public short shortArrayField[];

    public static short[] shortArrayMethodStatic( short arg[] ) {
        return arg;
    }

    public short[] shortArrayMethod( short arg[] ) {
        return arg;
    }

    public static short short2dArrayFieldStatic[][];
    public short short2dArrayField[][];

    public static short[][] short2dArrayMethodStatic( short arg[][] ) {
        return arg;
    }

    public short[][] short2dArrayMethod( short arg[][] ) {
        return arg;
    }

    public static int intFieldStatic;
    public int intField;

    public static int intMethodStatic( int arg ) {
        return arg;
    }

    public int intMethod( int arg ) {
        return arg;
    }

    public static int intArrayFieldStatic[];
    public int intArrayField[];

    public static int[] intArrayMethodStatic( int arg[] ) {
        return arg;
    }

    public int[] intArrayMethod( int arg[] ) {
        return arg;
    }

    public static int int2dArrayFieldStatic[][];
    public int int2dArrayField[][];

    public static int[][] int2dArrayMethodStatic( int arg[][] ) {
        return arg;
    }

    public int[][] int2dArrayMethod( int arg[][] ) {
        return arg;
    }

    public static long longFieldStatic;
    public long longField;

    public static long longMethodStatic( long arg ) {
        return arg;
    }

    public long longMethod( long arg ) {
        return arg;
    }

    public static long longArrayFieldStatic[];
    public long longArrayField[];

    public static long[] longArrayMethodStatic( long arg[] ) {
        return arg;
    }

    public long[] longArrayMethod( long arg[] ) {
        return arg;
    }

    public static long long2dArrayFieldStatic[][];
    public long long2dArrayField[][];

    public static long[][] long2dArrayMethodStatic( long arg[][] ) {
        return arg;
    }

    public long[][] long2dArrayMethod( long arg[][] ) {
        return arg;
    }

    public static float floatFieldStatic;
    public float floatField;

    public static float floatMethodStatic( float arg ) {
        return arg;
    }

    public float floatMethod( float arg ) {
        return arg;
    }

    public static float floatArrayFieldStatic[];
    public float floatArrayField[];

    public static float[] floatArrayMethodStatic( float arg[] ) {
        return arg;
    }

    public float[] floatArrayMethod( float arg[] ) {
        return arg;
    }

    public static float float2dArrayFieldStatic[][];
    public float float2dArrayField[][];

    public static float[][] float2dArrayMethodStatic( float arg[][] ) {
        return arg;
    }

    public float[][] float2dArrayMethod( float arg[][] ) {
        return arg;
    }

    public static double doubleFieldStatic;
    public double doubleField;

    public static double doubleMethodStatic( double arg ) {
        return arg;
    }

    public double doubleMethod( double arg ) {
        return arg;
    }

    public static double doubleArrayFieldStatic[];
    public double doubleArrayField[];

    public static double[] doubleArrayMethodStatic( double arg[] ) {
        return arg;
    }

    public double[] doubleArrayMethod( double arg[] ) {
        return arg;
    }

    public static double double2dArrayFieldStatic[][];
    public double double2dArrayField[][];

    public static double[][] double2dArrayMethodStatic( double arg[][] ) {
        return arg;
    }

    public double[][] double2dArrayMethod( double arg[][] ) {
        return arg;
    }

    public static String StringFieldStatic;
    public String StringField;

    public static String StringMethodStatic( String arg ) {
        return arg;
    }

    public String StringMethod( String arg ) {
        return arg;
    }

    public static String StringArrayFieldStatic[];
    public String StringArrayField[];

    public static String[] StringArrayMethodStatic( String arg[] ) {
        return arg;
    }

    public String[] StringArrayMethod( String arg[] ) {
        return arg;
    }

    public static String String2dArrayFieldStatic[][];
    public String String2dArrayField[][];

    public static String[][] String2dArrayMethodStatic( String arg[][] ) {
        return arg;
    }

    public String[][] String2dArrayMethod( String arg[][] ) {
        return arg;
    }

}
